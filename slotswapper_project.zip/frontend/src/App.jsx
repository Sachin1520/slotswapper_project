import React from 'react';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Dashboard from './pages/Dashboard';

export default function App(){
  const token = localStorage.getItem('token');
  if(!token) return <div><h2>SlotSwapper (Frontend Scaffold)</h2><Login/><Signup/></div>;
  return <Dashboard />;
}
