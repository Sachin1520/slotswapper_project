const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4000/api';

function authHeaders(){
  const token = localStorage.getItem('token');
  return token ? { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } : { 'Content-Type': 'application/json' };
}

export async function signup(data){
  return fetch(`${API_BASE}/signup`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(r=>r.json());
}
export async function login(data){
  return fetch(`${API_BASE}/login`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)}).then(r=>r.json());
}

export async function getMyEvents(){
  return fetch(`${API_BASE}/events`,{headers:authHeaders()}).then(r=>r.json());
}
export async function getSwappableSlots(){
  return fetch(`${API_BASE}/swappable-slots`,{headers:authHeaders()}).then(r=>r.json());
}
export async function createSwapRequest(mySlotId,theirSlotId){
  return fetch(`${API_BASE}/swap-request`,{method:'POST',headers:authHeaders(),body:JSON.stringify({mySlotId,theirSlotId})}).then(r=>r.json());
}
export async function respondSwap(requestId,accept){
  return fetch(`${API_BASE}/swap-response/${requestId}`,{method:'POST',headers:authHeaders(),body:JSON.stringify({accept})}).then(r=>r.json());
}
export async function getIncomingRequests(){ return fetch(`${API_BASE}/requests/incoming`,{headers:authHeaders()}).then(r=>r.json()); }
export async function getOutgoingRequests(){ return fetch(`${API_BASE}/requests/outgoing`,{headers:authHeaders()}).then(r=>r.json()); }
export async function updateEventStatus(id, body){ return fetch(`${API_BASE}/events/${id}`,{method:'PATCH',headers:authHeaders(),body:JSON.stringify(body)}).then(r=>r.json()); }
