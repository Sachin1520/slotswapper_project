import React, {useState} from 'react';
import { login } from '../api/api';

export default function Login(){
  const [email,setEmail]=useState(''), [password,setPassword]=useState('');
  async function submit(e){
    e.preventDefault();
    const res = await login({email,password});
    if(res.token){ localStorage.setItem('token', res.token); window.location.reload(); }
    else alert(res.error || 'Login failed');
  }
  return (
    <form onSubmit={submit}>
      <h3>Login</h3>
      <input placeholder='email' value={email} onChange={e=>setEmail(e.target.value)}/>
      <input placeholder='password' type='password' value={password} onChange={e=>setPassword(e.target.value)}/>
      <button type='submit'>Login</button>
    </form>
  );
}
