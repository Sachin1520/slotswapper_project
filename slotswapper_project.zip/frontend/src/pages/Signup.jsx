import React, {useState} from 'react';
import { signup } from '../api/api';

export default function Signup(){
  const [name,setName]=useState(''), [email,setEmail]=useState(''), [password,setPassword]=useState('');
  async function submit(e){
    e.preventDefault();
    const res = await signup({name,email,password});
    if(res.token){ localStorage.setItem('token', res.token); window.location.reload(); }
    else alert(res.error || 'Signup failed');
  }
  return (
    <form onSubmit={submit}>
      <h3>Signup</h3>
      <input placeholder='name' value={name} onChange={e=>setName(e.target.value)}/>
      <input placeholder='email' value={email} onChange={e=>setEmail(e.target.value)}/>
      <input placeholder='password' type='password' value={password} onChange={e=>setPassword(e.target.value)}/>
      <button type='submit'>Signup</button>
    </form>
  );
}
