import React, {useEffect, useState} from 'react';
import { getMyEvents, getSwappableSlots, createSwapRequest, getIncomingRequests, getOutgoingRequests, updateEventStatus } from '../api/api';

export default function Dashboard(){
  const [events,setEvents]=useState([]), [market,setMarket]=useState([]), [incoming,setIncoming]=useState([]), [outgoing,setOutgoing]=useState([]);

  async function load(){
    setEvents(await getMyEvents());
    setMarket(await getSwappableSlots());
    setIncoming(await getIncomingRequests());
    setOutgoing(await getOutgoingRequests());
  }
  useEffect(()=>{ load(); },[]);

  async function makeSwappable(id){
    await updateEventStatus(id, {status:'SWAPPABLE'});
    load();
  }

  return (
    <div>
      <h2>Dashboard</h2>
      <h3>Your Events</h3>
      <ul>{events.map(e=>(
        <li key={e.id}>{e.title} [{e.status}] {e.status==='BUSY' && <button onClick={()=>makeSwappable(e.id)}>Make Swappable</button>}</li>
      ))}</ul>

      <h3>Marketplace (Other users' swappable slots)</h3>
      <ul>{market.map(s=>(
        <li key={s.id}>{s.title} by {s.owner_name} ({s.start_time} - {s.end_time})</li>
      ))}</ul>

      <h3>Incoming Requests</h3>
      <ul>{incoming.map(r=>(
        <li key={r.id}>{r.requester_name} offered "{r.my_title}" for your "{r.their_title}" - Status: {r.status}</li>
      ))}</ul>

      <h3>Outgoing Requests</h3>
      <ul>{outgoing.map(r=>(
        <li key={r.id}>To {r.responder_name}: "{r.my_title}" -> "{r.their_title}" - {r.status}</li>
      ))}</ul>
    </div>
  );
}
