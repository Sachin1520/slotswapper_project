const express = require('express');
const db = require('../db');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.use(auth);

router.get('/swappable-slots', async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await db.query(
      `SELECT e.*, u.name AS owner_name, u.email AS owner_email
       FROM events e JOIN users u ON e.owner_id = u.id
       WHERE e.status = 'SWAPPABLE' AND e.owner_id <> $1
       ORDER BY e.start_time`,
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/swap-request', async (req, res) => {
  const { mySlotId, theirSlotId } = req.body;
  const requesterId = req.user.id;
  const client = await db.pool.connect();

  try {
    await client.query('BEGIN');

    const myRes = await client.query('SELECT * FROM events WHERE id=$1 FOR UPDATE', [mySlotId]);
    const my = myRes.rows[0];
    if (!my) throw { status: 404, msg: 'My slot not found' };
    if (my.owner_id !== requesterId) throw { status: 403, msg: 'Not owner of mySlotId' };
    if (my.status !== 'SWAPPABLE') throw { status: 400, msg: 'My slot not SWAPPABLE' };

    const theirRes = await client.query('SELECT * FROM events WHERE id=$1 FOR UPDATE', [theirSlotId]);
    const their = theirRes.rows[0];
    if (!their) throw { status: 404, msg: 'Their slot not found' };
    if (their.owner_id === requesterId) throw { status: 400, msg: 'Cannot swap with your own slot' };
    if (their.status !== 'SWAPPABLE') throw { status: 400, msg: 'Their slot not SWAPPABLE' };

    const insertRes = await client.query(
      `INSERT INTO swap_requests (requester_id, responder_id, my_event_id, their_event_id, status)
       VALUES ($1,$2,$3,$4,'PENDING') RETURNING *`,
      [requesterId, their.owner_id, mySlotId, theirSlotId]
    );
    const swapRequest = insertRes.rows[0];

    await client.query('UPDATE events SET status=$1 WHERE id=$2', ['SWAP_PENDING', mySlotId]);
    await client.query('UPDATE events SET status=$1 WHERE id=$2', ['SWAP_PENDING', theirSlotId]);

    await client.query('COMMIT');
    res.json({ swapRequest });
  } catch (err) {
    await client.query('ROLLBACK');
    if (err.status) return res.status(err.status).json({ error: err.msg });
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

router.post('/swap-response/:requestId', async (req, res) => {
  const responderId = req.user.id;
  const { requestId } = req.params;
  const { accept } = req.body; // boolean
  const client = await db.pool.connect();

  try {
    await client.query('BEGIN');

    const srRes = await client.query('SELECT * FROM swap_requests WHERE id=$1 FOR UPDATE', [requestId]);
    const sr = srRes.rows[0];
    if (!sr) throw { status: 404, msg: 'SwapRequest not found' };
    if (sr.responder_id !== responderId) throw { status: 403, msg: 'Not authorized to respond' };
    if (sr.status !== 'PENDING') throw { status: 400, msg: 'SwapRequest not pending' };

    const myEvtRes = await client.query('SELECT * FROM events WHERE id=$1 FOR UPDATE', [sr.my_event_id]);
    const theirEvtRes = await client.query('SELECT * FROM events WHERE id=$1 FOR UPDATE', [sr.their_event_id]);
    const myEvt = myEvtRes.rows[0];
    const theirEvt = theirEvtRes.rows[0];
    if (!myEvt || !theirEvt) throw { status: 404, msg: 'One of the events not found' };

    if (!accept) {
      await client.query('UPDATE swap_requests SET status=$1, updated_at=NOW() WHERE id=$2', ['REJECTED', requestId]);
      await client.query('UPDATE events SET status=$1 WHERE id=$2', ['SWAPPABLE', sr.my_event_id]);
      await client.query('UPDATE events SET status=$1 WHERE id=$2', ['SWAPPABLE', sr.their_event_id]);
      await client.query('COMMIT');
      return res.json({ message: 'Rejected' });
    }

    if (myEvt.status !== 'SWAP_PENDING' || theirEvt.status !== 'SWAP_PENDING') {
      throw { status: 400, msg: 'One or more events not in SWAP_PENDING' };
    }

    const requesterId = sr.requester_id;
    const responderIdFromRow = sr.responder_id;

    // swap ownership: do two explicit updates
    await client.query('UPDATE events SET owner_id=$1, status=$2 WHERE id=$3', [responderIdFromRow, 'BUSY', sr.my_event_id]);
    await client.query('UPDATE events SET owner_id=$1, status=$2 WHERE id=$3', [requesterId, 'BUSY', sr.their_event_id]);

    await client.query('UPDATE swap_requests SET status=$1, updated_at=NOW() WHERE id=$2', ['ACCEPTED', requestId]);

    await client.query('COMMIT');
    res.json({ message: 'Accepted' });
  } catch (err) {
    await client.query('ROLLBACK');
    if (err.status) return res.status(err.status).json({ error: err.msg });
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  } finally {
    client.release();
  }
});

router.get('/requests/incoming', async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await db.query(
      `SELECT sr.*, me.title as my_title, te.title as their_title, u_req.name as requester_name
       FROM swap_requests sr
       JOIN events me ON sr.my_event_id = me.id
       JOIN events te ON sr.their_event_id = te.id
       JOIN users u_req ON sr.requester_id = u_req.id
       WHERE sr.responder_id = $1
       ORDER BY sr.created_at DESC`,
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/requests/outgoing', async (req, res) => {
  try {
    const userId = req.user.id;
    const result = await db.query(
      `SELECT sr.*, me.title as my_title, te.title as their_title, u_res.name as responder_name
       FROM swap_requests sr
       JOIN events me ON sr.my_event_id = me.id
       JOIN events te ON sr.their_event_id = te.id
       JOIN users u_res ON sr.responder_id = u_res.id
       WHERE sr.requester_id = $1
       ORDER BY sr.created_at DESC`,
      [userId]
    );
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
