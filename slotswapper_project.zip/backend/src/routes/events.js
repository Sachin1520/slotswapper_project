const express = require('express');
const db = require('../db');
const auth = require('../middleware/authMiddleware');
const router = express.Router();

router.use(auth);

router.post('/', async (req, res) => {
  try {
    const { title, startTime, endTime, status } = req.body;
    const ownerId = req.user.id;
    const result = await db.query(
      'INSERT INTO events (owner_id, title, start_time, end_time, status) VALUES ($1,$2,$3,$4,$5) RETURNING *',
      [ownerId, title, startTime, endTime, status || 'BUSY']
    );
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/', async (req, res) => {
  try {
    const ownerId = req.user.id;
    const result = await db.query('SELECT * FROM events WHERE owner_id=$1 ORDER BY start_time', [ownerId]);
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

router.patch('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const ownerId = req.user.id;
    const allowed = ['title','start_time','end_time','status'];
    const fields = Object.keys(req.body).filter(f => allowed.includes(f));
    if (!fields.length) return res.status(400).json({ error: 'No valid fields' });

    const setParts = fields.map((f, i) => `${f}=$${i+1}`).join(',');
    const values = fields.map(f => req.body[f]);
    values.push(id, ownerId);

    const query = `UPDATE events SET ${setParts} WHERE id=$${fields.length+1} AND owner_id=$${fields.length+2} RETURNING *`;
    const result = await db.query(query, values);
    if (!result.rows[0]) return res.status(404).json({ error: 'Not found or not owner' });
    res.json(result.rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
