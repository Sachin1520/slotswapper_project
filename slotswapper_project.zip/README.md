# SlotSwapper - Ready project scaffold

This archive contains a ready-to-run scaffold for SlotSwapper: backend (Express + Postgres) and a minimal React frontend (Vite).

## What you get
- backend/: Express API with auth, events, and swap logic (transactions)
- frontend/: Minimal React app to demo basic flows (signup/login, dashboard)

## How to run locally

### Backend
1. Create a Postgres database and run `backend/schema.sql` to create tables.
2. Copy `backend/.env.example` to `backend/.env` and set `DATABASE_URL` and `JWT_SECRET`.
3. Install & run:
   ```
   cd backend
   npm install
   npm start
   ```

### Frontend
```
cd frontend
npm install
npm run dev
```

## To push to GitHub
1. Create a new repository on GitHub.
2. From this project root:
   ```
   git init
   git add .
   git commit -m "Initial commit - SlotSwapper scaffold"
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```

## Notes
- This scaffold focuses on core swap logic and basic UI. Expand the frontend for modals, routing, and better UX.
- For demo purposes the frontend stores JWT in localStorage (ok for a coding challenge, but consider secure cookies for production).
